// getting-started.js
const mongoose = require('mongoose');

main().catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://localhost:27017/test');// use `await mongoose.connect('mongodb://user:password@localhost:27017/test');` if your database has auth enabled
}
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
    console.log("We are connected");
})


// Schema simply tells us what type of data the user wants to store.
const kittySchema = new mongoose.Schema({
  name: String
});//The kitten schema is now converted into a kitten model. The basic difference between schema and model is, schema lets you know which field is to be assigned and model is the final compiled schema. 

// Once we have complied the schema to the object, we can make the objects.
var harrykitten= new Kitten({ name: 'harryKitty' });
console.log(harrykitty.name); // 'Silence'
// We have to write node index.js to excute the above line



// we have to explicitly tell the mongoose that we are going to store the data
kittySchema.methods.speak = function () {
  var greeting = this.name
  console.log(greeting);
}
// Node Js works according to a non-blocking model which means all the code will run from top to bottom and all the callbacks will run at last.  


// To save the data in the database 
harrykitty.save(function (err, harrykitty) {
  if (err) return console.error(err);
  harrykitty.speak();
});



